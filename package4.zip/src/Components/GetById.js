import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
// import Update from "./Update";
const appURL = "https://65e3190788c4088649f54e9b.mockapi.io/Student";
function GetById() {
  // const { id } = useParams();
  const [student, setStudent] = useState([]);
  const navigate = useNavigate();
  const params = useParams();
  useEffect(() => {
    fetch(appURL + "/" + params.id)
      .then((response) => response.json())
      .then((data) => setStudent(data));
  }, []);
  return (
    <>
      <div className="p-3 m-4 mb-3 me-1 card col-6 border border-secondary border-2">
        <img
          className="border rounded-pill"
          src={student.avatar}
          alt="Avatar"
        />
        <div className="card-body">
          <h4 className="card-title">{student.name}</h4>
          <p className="card-text">Some Data</p>

          <Link className="btn btn-secondary m-2" to="/">
            Back
          </Link>
          <button
            className="btn btn-danger m-2"
            onClick={() => {
              fetch(appURL + "/" + params.id, {
                method: "DELETE",
              })
                .then((response) => response.json())
                .then((data) => console.log(data), navigate("/"));
            }}
          >
            Delete
          </button>
          <Link to={"./update/"}>
            <button className="btn btn-primary m-2">Edit</button>
          </Link>
          {/* <button
            className="btn btn-primary m-2"
            onClick={() => {
              navigate("./update/" + id);
            }}
          >
            Edit
          </button> */}
        </div>
      </div>
    </>
  );
}

export default GetById;
