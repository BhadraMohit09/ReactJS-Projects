function useNewHook() {
  return (
    <>
      <h1>useNewHook</h1>
    </>
  );
}
export default useNewHook;
