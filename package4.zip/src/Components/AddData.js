import { useNavigate, useEffect } from "react-router-dom";
import { useState } from "react";
const appURL = "https://65e3190788c4088649f54e9b.mockapi.io/Student";

function AddData() {
  const [data, setData] = useState({});
  const navigate = useNavigate();
  return (
    <>
      <div className="container p-3">
        <input
          placeholder="Name"
          type="text"
          onChange={(e) => {
            setData({ ...data, name: e.target.value });
          }}
        />
        <input
          className="m-3"
          placeholder="Image"
          type="text"
          onChange={(e) => {
            setData({ ...data, avatar: e.target.value });
          }}
        />
        <input
          placeholder="Description"
          type="text"
          onChange={(e) => {
            setData({ ...data, description: e.target.value });
          }}
        />
        <br />
        <button
          className="btn btn-primary m-2 w-25"
          type="button"
          onClick={() => {
            fetch(appURL, {
              method: "POST",
              body: JSON.stringify(data),
              headers: {
                "Content-Type": "application/json",
              },
            }).then(() => {
              navigate("/");
            });
          }}
        >
          Add
        </button>
      </div>
    </>
  );
}

export default AddData;
