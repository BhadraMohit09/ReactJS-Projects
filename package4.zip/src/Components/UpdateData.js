import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";
const apiUrl = "https://65e3190788c4088649f54e9b.mockapi.io/Student";

function UpdateData() {
  const [data, setData] = useState({});
  const navigate = useNavigate();
  const { id } = useParams();
  useEffect(() => {
    fetch(apiUrl + "/" + id)
      .then((res) => res.json())
      .then((res) => setData(res));
  }, []);
  return (
    <>
      <input
        className="m-3 p-2 border rounded-pill border-2 w-50 border-dark"
        type="text"
        value={data.name}
        onChange={(e) => {
          setData({ ...data, name: e.target.value });
        }}
      />
      <br />
      <input
        className="m-3 p-2 border rounded-pill border-2 w-50 border-dark"
        type="text"
        value={data.avatar}
        onChange={(e) => {
          setData({ ...data, avatar: e.target.value });
        }}
      />
      <br />
      <input
        className="m-3 p-2 border rounded-pill border-2 w-50 border-dark"
        type="text"
        value={data.description}
        onChange={(e) => {
          setData({ ...data, description: e.target.value });
        }}
      />
      <br />
      <button
        className="btn btn-secondary w-25 m-3"
        onClick={() => {
          fetch(apiUrl + "/" + id, {
            method: "PUT",
            body: JSON.stringify(data),
            headers: {
              "Content-Type": "application/json",
            },
          })
            .then((res) => {
              return res.json();
            })
            .then(() => {
              navigate("/");
            });
        }}
      >
        Save
      </button>
    </>
  );
}

export default UpdateData;
