import { useEffect, useState } from "react";
import useNewHook from "./NewHook";
import { Link } from "react-router-dom";
const appURL = "https://65e3190788c4088649f54e9b.mockapi.io/Student";
function GetAll() {
  const [students, setStudents] = useState([]);
  useEffect(() => {
    fetch(appURL)
      .then((response) => response.json())
      .then((data) => setStudents(data));
  }, []);
  const fomartedData = students.map((student) => {
    return (
      <>
        <div className="container-fluid p-2 bg-secondary text-white mb-2 m-1 ms-5 card col-3 border border-secondary border-2">
          <img
            className="border rounded-pill"
            src={student.avatar}
            alt="Avatar"
          />
          <div className="card-body">
            <h4 className="card-title">{student.name}</h4>
            <p className="card-text">Some Data</p>
            <Link
              className="btn btn-dark text-white opacity-75"
              to={"/" + student.id}
            >
              View More
            </Link>
          </div>
        </div>
      </>
    );
  });
  return (
    <>
      <h1>{<useNewHook />}</h1>
      <Link className="btn btn-primary m-4 w-25" to="/add">
        Add Items
      </Link>
      <div className="row">{fomartedData}</div>
    </>
  );
}
export default GetAll;
