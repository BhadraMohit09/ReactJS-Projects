import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { Route } from "react-router-dom";
import { Routes } from "react-router-dom";
import { BrowserRouter } from "react-router-dom";
import GetAll from "./Components/GetAll";
import GetById from "./Components/GetById";
import AddData from "./Components/AddData";
import UpdateData from "./Components/UpdateData";
import App from "./App";

const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

root.render(
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<GetAll />} />
      <Route path="/:id" element={<GetById />} />
      <Route path="/add" element={<AddData />} />
      <Route path="/:id/update" element={<UpdateData />} />
    </Routes>
  </BrowserRouter>
);
