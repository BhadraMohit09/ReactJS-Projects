import { useEffect, useState } from "react";
import Card from "./Components/Card";

function Student() {
  const appURL = "https://65ded7fdff5e305f32a09e5b.mockapi.io/student";

  const [student, setData] = useState([]);
  useEffect(() => {
    fetch(appURL)
      .then((res) => res.json())
      .then((res) => {
        setData(res);
      });
  }, []);
  return (
    <>
      {student.map((e) => {
        return (
          <div className="container">
            <Card name={e.name} img={e.avatar} />
          </div>
        );
      })}
    </>
  );
}
export default Student;
