function Card(props) {
  return (
    <>
      <div className="container col-10 text-center">
        <div class="card">
          <img
            src={props.img}
            className="card-img-top border rounded-pill"
            alt="..."
          />
          <div class="card-body">
            <h5 class="card-title">{props.name}</h5>
            <p class="card-text">{props.title}</p>
            <a href="#" class="btn btn-primary">
              Go somewhere
            </a>
          </div>
        </div>
      </div>
    </>
  );
}

export default Card;
