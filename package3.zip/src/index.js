import { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import Card from "./Components/Card";
import App from "./App";
import Student from "./Student";
const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

root.render(
  <>
    <Student />
  </>
);
