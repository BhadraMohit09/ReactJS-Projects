function NewMapping() {
  const array = [
    {
      img: "https://darshan.ac.in/U01/Faculty-Photo/5---29-04-2023-11-00-29.jpg",
      name: "Dr. Gopi Sanghani",
      qualification: "PHD",
      btn: "Know More",
    },
    {
      img: "https://darshan.ac.in/U01/Faculty-Photo/3---28-04-2023-02-02-42.jpg",
      name: "Dr. Nilesh Gambhava",
      qualification: "PHD",
      btn: "Know More",
    },
    {
      img: "https://darshan.ac.in/U01/Faculty-Photo/6---28-04-2023-02-06-07.jpg",
      name: "Prof. Arjun Bala",
      qualification: "M.Tech",
      btn: "Know More",
    },
  ];
  return array.map((e) => {
    return (
      <div className="card col m-3 p-2 shadow-lg">
        <img className="border rounded-pill p-2" src={e.img} />
        <div className="card-body text-center fs-3">
          <h5 className="card-title text-center">{e.name}</h5>
          <p>{e.qualification}</p>
          <p className="card-text">Some quick example text</p>
          {/* <a
            href="#"
            onClick={props.click}
            className="btn btn-secondary border rounded-4"
          >
            {e.btn}
          </a> */}
        </div>
      </div>
    );
  });
}

export default NewMapping;
