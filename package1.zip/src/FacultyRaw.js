function FacultyRaw(props) {
  return (
    <>
      <div className="col m-2">
        <img width="100%" src={props.img} />
        <h3>{props.name}</h3>
        <p>{props.qualification}</p>
      </div>
    </>
  );
}

export default FacultyRaw;
