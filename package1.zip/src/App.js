import "./styles.css";
import Faculty from "./Faculty";
import FacultyRaw from "./FacultyRaw";
import NavBar from "./NavBar";
import Mapping from "./Mapping";
import NewMapping from "./NewMapping";
export default function App() {
  return (
    <>
      <NavBar />
      <div className="container p-3">
        <div className="row">
          <Faculty
            name="Dr. Gopi Sanghani"
            qualification="PHD"
            img="https://darshan.ac.in/U01/Faculty-Photo/5---29-04-2023-11-00-29.jpg"
            btn="Know More"
          />
          <Faculty
            name="Dr. Nilesh Gambhava"
            qualification="PHD"
            img="https://darshan.ac.in/U01/Faculty-Photo/3---28-04-2023-02-02-42.jpg"
            btn="Know More"
          />

          <Faculty
            name="Dr. Pradyumansinh Jadeja"
            qualification="PHD"
            img="https://darshan.ac.in/U01/Faculty-Photo/6---28-04-2023-02-06-07.jpg"
            btn="Know More"
          />
        </div>
        <div className="row">
          <Faculty
            name="Prof. Maulik Trivedi"
            qualification="M.Tech"
            img="https://darshan.ac.in/U01/Faculty-Photo/8---28-04-2023-02-06-25.jpg"
            btn="Know More"
          />
          <Faculty
            name="Prof. Firoz Sherasiya"
            qualification="PHD"
            img="https://darshan.ac.in/U01/Faculty-Photo/12---28-04-2023-02-06-51.jpg"
            btn="Know More"
          />
          <Faculty
            name="Prof. Rupesh Vaishnav"
            qualification="PHD"
            img="https://darshan.ac.in/U01/Faculty-Photo/10---28-04-2023-02-07-03.jpg"
            btn="Know More"
          />
        </div>
        <div className="row">
          <Faculty
            name="Prof. Arjun Bala"
            qualification="M.Tech"
            img="https://darshan.ac.in/U01/Faculty-Photo/15---28-04-2023-02-07-35.jpg"
            btn="Know More"
          />
          <Faculty
            name="Prof. Naimish Sir"
            qualification="M.E"
            img="https://darshan.ac.in/U01/Faculty-Photo/214---28-04-2023-02-08-35.jpg"
            btn="Know More"
          />
          <Faculty
            name="Prof. Jayesh Vagadiya"
            qualification="M.E"
            img="https://darshan.ac.in/U01/Faculty-Photo/219---28-04-2023-02-09-01.jpg"
            btn="Know More"
          />
        </div>
      </div>
      <div className="container">
        <div className="row">
          <Mapping />
          <NewMapping />
        </div>
      </div>
    </>
  );
}
