function Faculty(props) {
  return (
    <>
      <div className="card col m-3 p-2 shadow-lg">
        <img className="border rounded-pill p-2" src={props.img} />
        <div className="card-body text-center fs-3">
          <h5 className="card-title text-center">{props.name}</h5>
          <p>{props.qualification}</p>
          <p className="card-text">Some quick example text</p>
          <a
            href="#"
            onClick={props.click}
            className="btn btn-secondary border rounded-4"
          >
            {props.btn}
          </a>
        </div>
      </div>
    </>
  );
}

export default Faculty;
