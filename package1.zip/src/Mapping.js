import Faculty from "./Faculty";
function Mapping() {
  const data = [
    {
      img: "https://darshan.ac.in/U01/Faculty-Photo/5---29-04-2023-11-00-29.jpg",
      name: "Dr. Gopi Sanghani",
      qualification: "PHD",
      btn: "Know More",
    },
    {
      img: "https://darshan.ac.in/U01/Faculty-Photo/3---28-04-2023-02-02-42.jpg",
      name: "Dr. Nilesh Gambhava",
      qualification: "PHD",
      btn: "Know More",
    },
    {
      img: "https://darshan.ac.in/U01/Faculty-Photo/6---28-04-2023-02-06-07.jpg",
      name: "Prof. Arjun Bala",
      qualification: "M.Tech",
      btn: "Know More",
    },
  ];
  return data.map((e) => {
    return (
      <Faculty
        img={e.img}
        name={e.name}
        qualification={e.qualification}
        btn={e.btn}
      />
    );
  });
}
export default Mapping;
