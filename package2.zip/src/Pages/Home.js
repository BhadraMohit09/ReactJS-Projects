import { useState } from "react";
function Home() {
  data = [
    {
      id: 1,
      name: "User1",
      age: 20,
    },
    {
      id: 2,
      name: "User2",
      age: 40,
    },
    {
      id: 3,
      name: "User3",
      age: 35,
    },
  ];
  const [student, setData] = useState(data);
  const [addData, setAddData] = useState({ name: "", age: "" });
  function Delete(id) {
    setData(
      student.filter((e) => {
        return e.id !== id;
      })
    );
    console.log(student);
  }
  function handle(e) {
    setAddData({ ...addData, [e.target.name]: e.target.value });
  }
  function Add() {
    setData([...student, addData]);
    setAddData({ name: "", age: "" });
  }
  return (
    <>
      <div className="container-fluid mt-3">
        {student.map((e) => {
          return (
            <>
              <div className="container-fluid">
                <h4>Name: {e.name}</h4>
                <h4>Age: {e.age}</h4>
              </div>
            </>
          );
        })}
      </div>
      <button
        className="ms-3 w-25 bg-primary text-white border border-dark rounded-pill"
        onClick={() => Delete(1)}
      >
        Delete
      </button>
      <div className="container-fluid p-3">
        <form>
          <input
            placeholder="Enter name"
            type="text"
            name="name"
            onChange={handle}
          />
          <br />
          <input
            className="mt-2"
            placeholder="Enter Age"
            type="text"
            name="age"
            onChange={handle}
          />
        </form>
        <button
          onClick={Add}
          className="bg-primary text-white border rounded-pill mt-1 w-25"
        >
          Add
        </button>
      </div>
    </>
  );
}

export default Home;
