import "./styles.css";
function App() {
  return <h4>Hello</h4>;
}

export default App;
